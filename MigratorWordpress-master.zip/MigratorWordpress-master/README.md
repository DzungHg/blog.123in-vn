MigratorWordpress
=================

#####A ProcessMigrator subclass for migrating wordpress export files to Processwire.

As mentioned in the description this [ProcessWire](https://github.com/ryancramerdesign/ProcessWire) module is a submodule for ["ProcessMigrator"](https://github.com/adrianbj/ProcessMigrator). It allows to import the Wordpress Export file.

##How to export Wordpress

It's really easy thanks to their build-in exporter.

1. Go to "Tools" -> "Export". ![](http://codex.wordpress.org/images/thumb/9/9b/manageexport.png/800px-manageexport.png)
2. Follow the steps.



##How to import into Processwire

1. Install "ProcessMigrator" and this module (if you haven't already done).
2. Go to "Setup" -> "Migrator".
3. Choose "Import" and continue.
4. Choose your exported Wordpress .xml file.
5. Follow the steps.
